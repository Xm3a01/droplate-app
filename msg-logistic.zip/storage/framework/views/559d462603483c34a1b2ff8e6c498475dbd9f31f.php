<aside class="main-sidebar main-sidebar-custom sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/" class="brand-link">
        <img src="<?php echo e(asset('images/ms.png')); ?>" alt="AdminLTE Logo" class="brand-image  elevation-3"
            style="opacity: .8">
        <span class="brand-text font-weight-bold text-primary">Droplet</span> App
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(Route::is('home') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Manage-product')): ?>
                <li class="nav-item <?php echo e(Request::is('*employees*|*drivers*|*clients*') ? 'menu-is-opening menu-open' : ''); ?> ">
                    <a href="#" class="nav-link  <?php echo e(Request::is('*employees*') ? 'active' : ''); ?>">
                        
                        <i class="nav-icon fas fa-users"></i>
                        <p>
                            Users
                            <i class="fas fa-angle-left right"></i>
                            
                        </p>
                    </a>
                    
                    <ul class="nav nav-treeview text-xs">
                        <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('employees.index')); ?>"
                                class="nav-link <?php echo e(Request::is('*employees') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-users"></i>
                                <p class="">Employees</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('drivers.index')); ?>"
                                class="nav-link <?php echo e(Request::is('*drivers*') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-users"></i>
                                <p class="">Drivers</p>
                            </a>
                        </li>   
                        <?php endif; ?>
                       
                        <li class="nav-item">
                            <a href="<?php echo e(route('users.index')); ?>"
                                class="nav-link <?php echo e(Request::is('*users') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-users"></i>
                                <p class="">Clinets</p>
                            </a>
                        </li>        
                        
                    </ul>
                </li>
              
                
                <li class="nav-item <?php echo e(Request::is('*products*') ? 'menu-is-opening menu-open' : ''); ?> ">
                    <a href="#" class="nav-link  <?php echo e(Request::is('*products*') ? 'active' : ''); ?>">
                        
                        <i class="nav-icon fas fa-th"></i>
                        <p>
                            Products
                            <i class="fas fa-angle-left right"></i>
                            
                        </p>
                    </a>
                    <ul class="nav nav-treeview text-xs">
                        <li class="nav-item">
                            <a href="<?php echo e(route('products.index')); ?>"
                                class="nav-link <?php echo e(Request::is('*products') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-file-alt"></i>
                                <p class="">Products</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Manage-categories')): ?>
                <li class="nav-item <?php echo e(Request::is('*categories*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="<?php echo e(route('categories.index')); ?>"
                        class="nav-link <?php echo e(Request::is('*categories*') ? 'active' : ''); ?>"">
                        <i class="   nav-icon  fas fa-columns" aria-hidden="true"></i>
                        <p>
                            Categories
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview text-xs">
                        <li class="nav-item">
                            <a href="<?php echo e(route('categories.index')); ?>"
                                class="nav-link <?php echo e(Request::is('categories.index') ? 'tabed' : ''); ?>">
                                <i class="  fa fa-file-alt nav-icon text-xs"></i>
                                <p>Categories</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('sub_categories.index')); ?>"
                                class="nav-link <?php echo e(Route::is('sub_categories.index') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-thumbtack"></i>
                                <p class="">Sub categories</p>
                            </a>
                        </li>

                    </ul>

                </li>
               

                <li class="nav-item <?php echo e(Request::is('*cities*') || Request::is('*regions*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="" class="nav-link <?php echo e(Request::is('*cities*') || Request::is('*regions*') ? 'active' : ''); ?>">
                        <i class=" nav-icon fa fa-map"></i>
                        <p>
                            Cities & Regions
                            <i class="right fas fa-angle-left"></i>
                            
                        </p>
                    </a>
                    <ul class="nav nav-treeview text-xs">
                        <li class="nav-item">
                            <a href="<?php echo e(route('cities.index')); ?>"
                                class="nav-link <?php echo e(Route::is('cities.index') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-city"></i>
                                <p class="">cities</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('regions.index')); ?>"
                                class="nav-link <?php echo e(Route::is('regions.index') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-map"></i>
                                <p class="">Regions</p>
                            </a>
                        </li>
                        
                    </ul>
                </li>

                <li class="nav-item <?php echo e(Request::is('*promoes*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="" class="nav-link <?php echo e(Request::is('*promoes*') ? 'active' : ''); ?>">
                        <i class=" nav-icon fa fa-code"></i>
                        <p>
                            PromoCode
                            <i class="right fas fa-angle-left"></i>
                            
                        </p>
                    </a>
                    <ul class="nav nav-treeview text-xs">
                        <li class="nav-item">
                            <a href="<?php echo e(route('promoes.index')); ?>"
                                class="nav-link <?php echo e(Route::is('promoes.index') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-code"></i>
                                <p class="">promo codes</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item <?php echo e(Request::is('*ads*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="" class="nav-link <?php echo e(Request::is('*ads*') ? 'active' : ''); ?>">
                        <i class=" nav-icon  fa fa-thumbtack"></i>
                        <p>
                            Ads
                            <i class="right fas fa-angle-left"></i>
                            
                        </p>
                    </a>
                    <ul class="nav nav-treeview text-xs">
                        <li class="nav-item">
                            <a href="<?php echo e(route('ads.index')); ?>"
                                class="nav-link <?php echo e(Route::is('ads.index') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fa fa-thumbtack"></i>
                                <p class="">ads</p>
                            </a>
                        </li>
                        
                    </ul>
                </li>

                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Manage-reports')): ?>
                         
                <li class="nav-item <?php echo e(Request::is('*profits*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="" class="nav-link <?php echo e(Request::is('*profits*') ? 'active' : ''); ?>">
                        <i class=" nav-icon  fa fa-copy"></i>
                        <p>
                            Reports
                            <i class="right fas fa-angle-left"></i>
                            
                        </p>
                    </a>
                    <ul class="nav nav-treeview text-xs">
                        <li class="nav-item">
                            <a href="<?php echo e(route('profits')); ?>"
                                class="nav-link <?php echo e(Route::is('profits') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fas fa-chart-line"></i>
                                <p class="">Profits reports</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('delivery.price')); ?>"
                                class="nav-link <?php echo e(Route::is('delivery.price') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fas fa-chart-pie"></i>
                                <p class="">Delivery price reports</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('clients')); ?>"
                                class="nav-link <?php echo e(Route::is('clients') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fas fa-chart-bar"></i>
                                <p class="">Clients reports</p>
                            </a>
                        </li>
                        
                    </ul>
                </li>
                <?php endif; ?>

                <li class="nav-item <?php echo e(Request::is('*orders*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="" class="nav-link <?php echo e(Request::is('*orders*') ? 'active' : ''); ?>">
                        <i class=" nav-icon  fa fa-copy"></i>
                        <p>
                            Orders
                            <i class="right fas fa-angle-left"></i>
                            
                        </p>
                    </a>
                    <ul class="nav nav-treeview text-xs">
                        <li class="nav-item">
                            <a href="<?php echo e(route('orders.index')); ?>"
                                class="nav-link <?php echo e(Route::is('orders.index') ? 'tabed' : ''); ?>">
                                <i class="nav-icon text-sm fas fa-chart-line"></i>
                                <p class="">Order</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item <?php echo e(Request::is('*setting*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="<?php echo e(route('setting.index')); ?>" class="nav-link <?php echo e(Request::is('*setting*') ? 'active' : ''); ?>">
                        <i class=" nav-icon  fa fa-cog"></i>
                        <p>
                            Settings
                            
                            
                        </p>
                    </a>
                </li>
                 <li class="nav-item <?php echo e(Route::is('notifications.create') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="<?php echo e(route('notifications.create')); ?>" class="nav-link <?php echo e(Route::is('notifications.create') ? 'active' : ''); ?>">
                        <i class=" nav-icon  fa fa-bile"></i>
                        <p>
                            Notifications
                        </p>
                    </a>
                </li>
                <li class="nav-item <?php echo e(Request::is('*conditions*') ? 'menu-is-opening menu-open' : ''); ?>">
                    <a href="<?php echo e(route('conditions.index')); ?>" class="nav-link <?php echo e(Request::is('*conditions*') ? 'active' : ''); ?>">
                        <i class=" nav-icon  fa fa-cog"></i>
                        <p>
                            Conditions&Privacy
                        </p>
                    </a>
                </li>

               
            </ul>
            </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
    <style>
        .tabed {
            color: #fff !important;
        }

    </style>
</aside>
<?php /**PATH D:\Projects\msg-logistic\resources\views/app/_include/sidebar.blade.php ENDPATH**/ ?>