

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row justify-content-between">
                                <div class="col-md-11 " id="buttonData">
                                    <h3 class="card-title d-sm-none d-lg-block">
                                        Products
                                    </h3>
                                </div>
                                <div class="col-md-1">
                                  <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                  data-target="#modal-lg">
                                  <i class="fa fa-plus"></i> New
                                  </button>
                                </div>
                            </div>
                        </div>

                        <?php if (isset($component)) { $__componentOriginal8e48e812620f6fc2bd3413bfaaf3c96cbcd79ec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Product\ProductHtml::class, []); ?>
<?php $component->withName('product.product-html'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e48e812620f6fc2bd3413bfaaf3c96cbcd79ec0)): ?>
<?php $component = $__componentOriginal8e48e812620f6fc2bd3413bfaaf3c96cbcd79ec0; ?>
<?php unset($__componentOriginal8e48e812620f6fc2bd3413bfaaf3c96cbcd79ec0); ?>
<?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <div class="modal fade" id="modal-lg">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">New Product</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('products.store')); ?>" id="create-form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body" id="app">
                      <input-select 
                      items = "<?php echo e($categories); ?>"
                      sub_item = "sub_category"
                      title_1 = "Category"
                      title_2 = "Sub Category"
                      name_1 = "category_id"
                      name_2 = "sub_category_id"
                      > </input-select>
                
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-6">
                          <label>Product AR name</label>
                          <input
                            name="ar_name"
                            class="form-control form-control-sm thingSelect"
                            style="width: 100%"
                            placeholder="Arabic name"
                            required
                          />
                        </div>
                        <div class="col-md-6">
                          <label>Product EN name</label>
                          <input
                            name="en_name"
                            class="form-control form-control-sm"
                            style="width: 100%"
                            placeholder="English name"
                            required
                          />
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-6">
                          <label for="exampleInputEmail1">Quantity</label>
                          <input
                            type="text"
                            name="quantity"
                            class="form-control form-control-sm"
                            id="exampleInputEmail1"
                            placeholder="Enter Quantity"
                            required
                          />
                        </div>
                        <div class="col-md-6">
                          <label for="exampleInputEmail1">Discount</label>
                          <input
                            type="text"
                            name="discount"
                            class="form-control form-control-sm"
                            id=""
                            placeholder="Enter Discount"
                            value="0"
                          />
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-4">
                          <label for="exampleInputEmail1">Selling price</label>
                          <input
                            type="text"
                            name="selling_price"
                            class="form-control form-control-sm"
                            id=""
                            placeholder="Enter Selling price"
                            required
                          />
                        </div>
                        <!-- purchasing_price -->
                        <div class="col-md-4">
                          <label for="exampleInputEmail1">Wholesale price</label>
                          <input
                            type="text"
                            name="wholesale_price"
                            class="form-control form-control-sm"
                            id="exampleInputEmail1"
                            placeholder="Enter Wholesale price"
                            required
                          />
                        </div>
                        <div class="col-md-4">
                          <label for="exampleInputEmail1">Purchasing price</label>
                          <input
                            type="text"
                            name="purchasing_price"
                            class="form-control form-control-sm"
                            id="exampleInputEmail1"
                            placeholder="Enter Purchasing price"
                            required
                          />
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-12">
                          <label for="exampleInputEmail1">English Description</label>
                          <textarea
                            type="text"
                            name="en_description"
                            class="form-control form-control-sm"
                            id="exampleInputEmail1"
                            placeholder="Enter Description"
                            required
                          >
                          </textarea>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-12">
                          <label for="exampleInputEmail1">Arabic Description </label>
                          <textarea
                            type="text"
                            name="ar_description"
                            class="form-control form-control-sm"
                            id="exampleInputEmail1"
                            placeholder="Enter Description"
                            required
                          >
                          </textarea>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-12">
                          <input-image />
                        </div>    

                      </div>
                    </div>

                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php if (isset($component)) { $__componentOriginal10eb93d4d3398dff8d3a908c1940f6311b4bb37c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Product\ProductJs::class, ['route' => 'data.products']); ?>
<?php $component->withName('product.product-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10eb93d4d3398dff8d3a908c1940f6311b4bb37c)): ?>
<?php $component = $__componentOriginal10eb93d4d3398dff8d3a908c1940f6311b4bb37c; ?>
<?php unset($__componentOriginal10eb93d4d3398dff8d3a908c1940f6311b4bb37c); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views\app\product\index.blade.php ENDPATH**/ ?>