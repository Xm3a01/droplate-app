


<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-dark">
                <div class="card-header">
                    <h3 class="card-title">Update Driver</h3>
                </div>

                <form method="post" action="<?php echo e(route('drivers.update' , $driver->id)); ?>" id="app" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-body p-5" >
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                            <label>Regions</label>
                            <select
                                name="region_id"
                                class="form-control form-control-sm thingSelect"
                                style="width: 100%"
                                placeholder="Name"
                            >
                            <option value="">--select --</option>
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($driver->region_id == $region->id ? 'selected' : ''); ?> value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                            </div>
                            <div class="col-md-6">
                            <label>Cities</label>
                            <select
                                name="city_id"
                                class="form-control form-control-sm thingSelect"
                                style="width: 100%"
                                
                            >
                            <option value="">--Select--</option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($driver->city_id == $city->id ? 'selected' : ''); ?> value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                            </div>
                        </div>
                        </div>
                  
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-6">
                            <label>Name</label>
                            <input
                              name="name"
                              class="form-control form-control-sm thingSelect"
                              style="width: 100%"
                              placeholder="Name"
                              value="<?php echo e($driver->name); ?>"
                            />
                          </div>
                          <div class="col-md-6">
                            <label>Email</label>
                            <input
                              name="email"
                              type="email"
                              class="form-control form-control-sm"
                              style="width: 100%"
                              placeholder="E-mail"
                              value="<?php echo e($driver->email); ?>"
                            />
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          
                          <div class="col-md-12">
                            <label for="exampleInputEmail1">Password</label>
                            <input
                              type="password"
                              name="password"
                              class="form-control form-control-sm"
                              id=""
                              placeholder="EnterPassword"
                              
                            />
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          
                          <div class="col-md-12">
                            <label for="exampleInputEmail1">Phone</label>
                            <input
                              type="text"
                              name="phone"
                              class="form-control form-control-sm"
                              id=""
                              placeholder="Phone"
                              value="<?php echo e($driver->phone); ?>"
                            />
                          </div>
                        </div>
                        </div>
                      <div class="form-group">
                        <div class="row">
                          
                          <!-- purchasing_price -->
                          <div class="col-md-12">
                            <label for="exampleInputEmail1">Address</label>
                            <input
                              type="text"
                              name="address"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                              placeholder="Enter Address"
                              value="<?php echo e($driver->address); ?>"
                            />
                          </div>
                         
                        </div>
                      </div>
  
                      </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-sm btn-primary">Save Change</button>
                    </div>
                </form>
            </div> 
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/driver/edit.blade.php ENDPATH**/ ?>