<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Loading Reports</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>
    <div class="container mt-5">
        <table class="table table-bordered table-hover">
            <thead class="">
                <tr>
                    <th>Form</th>
                    <th>Form</th>
                    <th>Form</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($transfer->id); ?></td>
                        <td><?php echo e($transfer->created_at); ?></td>
                        <td><?php echo e($transfer->id); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
    <script>
        
    </script>
</body>

</html>
<?php /**PATH D:\Projects\msg-logistic\resources\views\app\category\report.blade.php ENDPATH**/ ?>