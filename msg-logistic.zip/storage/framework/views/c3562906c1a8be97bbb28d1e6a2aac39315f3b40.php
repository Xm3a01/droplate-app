


<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-dark">
                <div class="card-header">
                    <h3 class="card-title">Update Clinet</h3>
                </div>

                <form method="post" action="<?php echo e(route('users.update' , $user->id)); ?>" id="app" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-body p-5" >
                    
                    
                  
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-6">
                            <label>Name</label>
                            <input
                              name="name"
                              class="form-control form-control-sm thingSelect"
                              style="width: 100%"
                              placeholder="Name"
                              value="<?php echo e($user->name); ?>"
                            />
                          </div>
                          <div class="col-md-6">
                            <label>Email</label>
                            <input
                              name="email"
                              type="email"
                              class="form-control form-control-sm"
                              style="width: 100%"
                              placeholder="E-mail"
                              value="<?php echo e($user->email); ?>"
                            />
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          
                          <div class="col-md-12">
                            <label for="exampleInputEmail1">Password</label>
                            <input
                              type="password"
                              name="password"
                              class="form-control form-control-sm"
                              id=""
                              placeholder="EnterPassword"
                            />
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          
                          <div class="col-md-12">
                            <label for="exampleInputEmail1">Phone</label>
                            <input
                              type="text"
                              name="phone"
                              class="form-control form-control-sm"
                              id=""
                              placeholder="Phone"
                              value="<?php echo e($user->phone); ?>"
                            />
                          </div>
                        </div>
                        </div>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-6">
                            <label for="exampleInputEmail1">Gender</label>
                            <select
                             
                              name="gender"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                             
                            >
                            <option value="">Gender</option>
                            
                                <option <?php echo e($user->gender == 'Male' ? 'selected' : ''); ?> value="Male">Male</option>
                                <option <?php echo e($user->gender == 'Female' ? 'selected' : ''); ?> value="Female">Female</option>
                            
                          </select>
                          </div>
                          <!-- purchasing_price -->
                          <div class="col-md-6">
                            <label for="exampleInputEmail1">Address</label>
                            <input
                              type="text"
                              name="address"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                              placeholder="Enter Address"
                              value="<?php echo e($user->address); ?>"
                            />
                          </div>
                         
                        </div>
                      </div>

                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12">
                            <label for="">Age</label>
                            <input type="text" name="age" value="<?php echo e($user->age); ?>" id="" placeholder="Age" class="form-control form-control-sm">
                          </div>
                        </div>
                      </div>

                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12">
                            <label for="">Upload image</label>
                            <input type="file" name="image" id="" class="form-control form-control-sm">
                          </div>
                        </div>
                      </div>
  
                      </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-sm btn-primary">Save Change</button>
                    </div>
                </form>
            </div> 
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views\app\user\edit.blade.php ENDPATH**/ ?>