

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row justify-content-between">
                                <div class="col-md-11 " id="buttonData">
                                    <h3 class="card-title d-sm-none d-lg-block">
                                        Oders
                                    </h3>
                                </div>
                                <div class="col-md-1">
                                 
                                </div>
                            </div>
                        </div>

                        <?php if (isset($component)) { $__componentOriginal70dd9dee77659db6612286872132899289549695 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Order\OrderHtml::class, []); ?>
<?php $component->withName('order.order-html'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70dd9dee77659db6612286872132899289549695)): ?>
<?php $component = $__componentOriginal70dd9dee77659db6612286872132899289549695; ?>
<?php unset($__componentOriginal70dd9dee77659db6612286872132899289549695); ?>
<?php endif; ?> 

                    </div>

                </div>

            </div>

        </div>

    </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('js'); ?>
        <?php if (isset($component)) { $__componentOriginal9b148076b9f864a27729e744670f44b3e9747ebb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Order\OrderJs::class, []); ?>
<?php $component->withName('order.order-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b148076b9f864a27729e744670f44b3e9747ebb)): ?>
<?php $component = $__componentOriginal9b148076b9f864a27729e744670f44b3e9747ebb; ?>
<?php unset($__componentOriginal9b148076b9f864a27729e744670f44b3e9747ebb); ?>
<?php endif; ?>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/order/index.blade.php ENDPATH**/ ?>