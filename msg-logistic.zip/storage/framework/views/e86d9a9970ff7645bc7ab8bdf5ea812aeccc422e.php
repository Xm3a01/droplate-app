

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <!-- general form elements -->
        <div class="card card-dark">
            <div class="card-header">
                <h3 class="card-title">Show Product</h3>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th>Name</th>
                    <th>Ar name</th>
                </tr>
                <tr>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->getTranslation('name' , 'ar')); ?></td>
                </tr>
                <tr>
                    <th>Selling price</th>
                    <th>َQuantity</th>
                </tr>
                <tr>
                    <td><?php echo e($product->selling_price); ?></td>
                    <td><?php echo e($product->quantity); ?></td>
                </tr>
                <tr>
                    <th>Descripton</th>
                    <th>Ar descripton</th>
                </tr>
                <tr>
                    <td><?php echo e($product->descripton); ?></td>
                    <td><?php echo e($product->getTranslation('descripton' , 'ar')); ?></td>
                </tr>
                <tr>
                    <th>Category</th>
                    <th>Ar category</th>
                </tr>
                <tr>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->category->getTranslation('name' , 'ar')); ?></td>
                </tr>
                <tr>
                    <th>Sub category</th>
                    <th>Ar Sub category</th>
                </tr>
                <tr>
                    <td><?php echo e($product->subCategory->name); ?></td>
                    <td><?php echo e($product->subCategory->getTranslation('name' , 'ar')); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views\app\employee\show.blade.php ENDPATH**/ ?>