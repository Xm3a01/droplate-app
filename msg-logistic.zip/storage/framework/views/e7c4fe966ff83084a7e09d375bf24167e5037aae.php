


<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-11">
            <!-- general form elements -->
            <div class="card card-dark">
                <div class="card-header">
                    <h3 class="card-title">Update City</h3>
                </div>

                <form method="post" action="<?php echo e(route('cities.update', $city->id)); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-body p-5">
                        <div class="row">
                            <div class="col-md-12">
                                <label for="">Region</label>
                                <select type="text" placeholder="Region" name="region_id" id=""
                                    class="form-control form-control-sm" autocomplete="" required>
                                    <option value="">Region</option>
                                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($region->id == $city->region_id ? 'selected' : ''); ?> value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <label for="">City name</label>
                                <input type="text" placeholder="City name" name="city_en_name" id=""
                                    class="form-control form-control-sm" autocomplete="" required
                                    value="<?php echo e($city->getTranslation('name', 'en')); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">City Arabic name</label>
                                <input type="text" placeholder="City Arabic name" name="city_ar_name" id=""
                                    class="form-control form-control-sm" autocomplete="" required
                                    value="<?php echo e($city->getTranslation('name', 'ar')); ?>">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mt-2">
                                <label for="">Queck delivery price</label>
                                <input type="text" placeholder="Queck delivery price" name="regular_delivery_price" id=""
                                    class="form-control form-control-sm" autocomplete="" required
                                    value="<?php echo e($city->regular_delivery_price); ?>">

                            </div>
                            <div class="col-md-6 mt-2">
                                <label for="">Normal delivery price</label>
                                <input type="text" placeholder="Normal delivery price" name="fast_delivery_price" id=""
                                    class="form-control form-control-sm" autocomplete="" required
                                    value="<?php echo e($city->fast_delivery_price); ?>">

                            </div>
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/city/edit.blade.php ENDPATH**/ ?>