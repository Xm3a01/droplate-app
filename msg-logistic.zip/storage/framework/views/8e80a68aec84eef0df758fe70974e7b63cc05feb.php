
<?php $__env->startPush('css'); ?>
    <style>
        .warperContext {
            border: 1px solid rgb(235, 230, 230);
            border-radius: 5px;
            /* overflow-y: scroll; */
            padding: 4px;
            box-shadow: 2px 3px 4px #b7b3b3c3;
        }
        
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row justify-content-center">
       <div class="col-md-8">
           <!-- general form elements -->
           <div class="card card-dark">
               <div class="card-header">
                   <h3 class="card-title">Loaging Form</h3>
               </div>
               <!-- /.card-header -->
               <!-- form start -->
               <form method="post" action="<?php echo e(route('products.store')); ?>" id="app" enctype="multipart/form-data">
                   <?php echo csrf_field(); ?>  
                      <product-form 
                        categories = "<?php echo e($categories); ?>" 
                        errors = "<?php echo e(count($errors->all()) > 0 ? json_encode($errors->all()) : null); ?>"
                      ></product-form>
   
                   <div class="card-footer">
                       <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                   </div>
               </form>
           </div>
       </div>

   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views\app\employee\create.blade.php ENDPATH**/ ?>