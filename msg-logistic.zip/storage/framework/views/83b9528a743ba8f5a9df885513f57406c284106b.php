

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row justify-content-between">
                                <div class="col-md-11 " id="buttonData">
                                    <h3 class="card-title d-sm-none d-lg-block">
                                        Employees
                                    </h3>
                                </div>
                                <div class="col-md-1">
                                  <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                  data-target="#modal-lg">
                                  <i class="fa fa-plus"></i> New
                                  </button>
                                </div>
                            </div>
                        </div>

                        <?php if (isset($component)) { $__componentOriginal90eb15f9272768e7bf282724001b0fabebfe8024 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Employee\EmployeeHtml::class, []); ?>
<?php $component->withName('employee.employee-html'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eb15f9272768e7bf282724001b0fabebfe8024)): ?>
<?php $component = $__componentOriginal90eb15f9272768e7bf282724001b0fabebfe8024; ?>
<?php unset($__componentOriginal90eb15f9272768e7bf282724001b0fabebfe8024); ?>
<?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <div class="modal fade" id="modal-lg">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">New Employee</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('employees.store')); ?>" id="create-form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body" id="app">
                      <input-select 
                      items = "<?php echo e($regions); ?>"
                      sub_item = "cities"
                      title_1 = "Region"
                      title_2 = "City"
                      name_1 = "region_id"
                      name_2 = "city_id"
                      
                      > </input-select>
                
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-6">
                          <label>Name</label>
                          <input
                            name="name"
                            class="form-control form-control-sm thingSelect"
                            style="width: 100%"
                            placeholder="Name"
                          />
                        </div>
                        <div class="col-md-6">
                          <label>Email</label>
                          <input
                            name="email"
                            type="email"
                            class="form-control form-control-sm"
                            style="width: 100%"
                            placeholder="E-mail"
                          />
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                        
                        <div class="col-md-6">
                          <label for="exampleInputEmail1">Password</label>
                          <input
                            type="password"
                            name="password"
                            class="form-control form-control-sm"
                            id=""
                            placeholder="EnterPassword"
                          />
                        </div>
                        <div class="col-md-6">
                          <label for="exampleInputEmail1">Confirm password</label>
                          <input
                            type="password"
                            name="password_confirmaition"
                            class="form-control form-control-sm"
                            id=""
                            placeholder="Enter Confirm password"
                          />
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="row">
                        
                        <div class="col-md-12">
                          <label for="exampleInputEmail1">Phone</label>
                          <input
                            type="text"
                            name="phone"
                            class="form-control form-control-sm"
                            id=""
                            placeholder="Phone"
                          />
                        </div>
                      </div>
                      </div>
                    <div class="form-group">
                      <div class="row">
                        <div class="col-md-6">
                          <label for="exampleInputEmail1">Permissions / صلاحيات</label>
                          <select
                           
                            name="permission"
                            class="form-control form-control-sm"
                            id="exampleInputEmail1"
                           
                          >
                          <option value="">Permission</option>
                          <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                        <!-- purchasing_price -->
                        <div class="col-md-6">
                          <label for="exampleInputEmail1">Address</label>
                          <input
                            type="text"
                            name="address"
                            class="form-control form-control-sm"
                            id="exampleInputEmail1"
                            placeholder="Enter Address"
                          />
                        </div>
                       
                      </div>
                    </div>

                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php if (isset($component)) { $__componentOriginal2f77c265110cafab6cae1a0cff35bb3f3663b3e7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Employee\EmployeeJs::class, []); ?>
<?php $component->withName('employee.employee-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'data.products']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f77c265110cafab6cae1a0cff35bb3f3663b3e7)): ?>
<?php $component = $__componentOriginal2f77c265110cafab6cae1a0cff35bb3f3663b3e7; ?>
<?php unset($__componentOriginal2f77c265110cafab6cae1a0cff35bb3f3663b3e7); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/employee/index.blade.php ENDPATH**/ ?>