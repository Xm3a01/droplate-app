




    
    <div id="app">
        <example-component></example-component>
    </div>


   <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    
<?php /**PATH D:\Projects\msg-logistic\resources\views\test.blade.php ENDPATH**/ ?>