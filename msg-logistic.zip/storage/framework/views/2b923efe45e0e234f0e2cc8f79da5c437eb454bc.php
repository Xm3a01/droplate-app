<?php if(Session::has('success')): ?>
    <script>
    $(document).Toasts('create', {
            title: 'Sucess',
            class: 'bg-green px-5 m-2',
            daley: '3000',
            autohide: true,
            body: '<?php echo e(Session::get("success")); ?>'
        })
    </script>
<?php endif; ?>

<style>
    .tost {
        padding: 20px;
    }
</style><?php /**PATH D:\Projects\msg-logistic\resources\views/app/_include/message.blade.php ENDPATH**/ ?>