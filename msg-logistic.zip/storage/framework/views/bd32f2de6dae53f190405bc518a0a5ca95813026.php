


<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-11">
            <!-- general form elements -->
            <div class="card card-dark">
                <div class="card-header">
                    <h3 class="card-title">Update Region</h3>
                </div>

                <form method="post" action="<?php echo e(route('regions.update' , $region->id)); ?>" id="app" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                   <div class="form-body p-5">
                    <div class="row mt-2">
                        <div class="col-md-6">
                            <label for="">Region name</label>
                            <input type="text" placeholder="Region name" name="ar_name" id=""
                                class="form-control form-control-sm" autocomplete="" required
                                value="<?php echo e($region->getTranslation('name' , 'ar')); ?>"
                                >
                        </div>
                        <div class="col-md-6">
                          <label for="">Region Arabic name</label>
                            <input type="text" placeholder="Region Arabic name" name="en_name" id=""
                                class="form-control form-control-sm" autocomplete="" required
                                value="<?php echo e($region->getTranslation('name' , 'en')); ?>"
                                
                                >
                        
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6 mt-2">
                        <label for="">Queck delivery price</label>
                          <input type="text" placeholder="Queck delivery price" name="regular_delivery_price" id=""
                              class="form-control form-control-sm" autocomplete="" required
                              value="<?php echo e($region->regular_delivery_price); ?>"
                              >
                      
                      </div>
                      <div class="col-md-6 mt-2">
                        <label for="">Normal delivery price</label>
                          <input type="text" placeholder="Normal delivery price" name="fast_delivery_price" id=""
                              class="form-control form-control-sm" autocomplete="" required
                              value="<?php echo e($region->fast_delivery_price); ?>"
                              >
                      
                      </div>
                  </div>

                </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/region/edit.blade.php ENDPATH**/ ?>