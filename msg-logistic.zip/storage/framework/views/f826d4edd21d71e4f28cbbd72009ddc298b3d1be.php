<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      

      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-user"></i>
          
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header"><?php echo e(Auth::user()->name); ?> <br> <?php echo e(Auth::user()->email); ?><small></small></span>
          <div class="dropdown-divider"></div>
          <a href="<?php echo e(route('profile.edit' , Auth::user()->id)); ?>" class="dropdown-item">
            <i class="fas fa-user mr-2"></i> Profile
            <span class="float-right text-muted text-sm"></span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item" 
          href="<?php echo e(route('admin.logout')); ?>"
          onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
           
            <!-- Message Start -->
            <div class="media">
              
              <div class="media-body row">
                <h3 class="dropdown-item-title col-md-1"> 
                  <span class="float-left text-sm text-danger"><i class="fas fa-lock"></i></span>
                </h3>
                <p class="text-sm col-md-2"><?php echo e(__('Logout')); ?></p>
                
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
         
          <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
      </li>
      <!-- Notifications Dropdown Menu -->
      
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      
    </ul>
  </nav>
  <!-- /.navbar --><?php /**PATH D:\Projects\msg-logistic\resources\views/app/_include/navbar.blade.php ENDPATH**/ ?>