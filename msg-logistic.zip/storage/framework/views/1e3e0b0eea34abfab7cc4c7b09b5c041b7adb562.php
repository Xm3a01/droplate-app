
<?php $__env->startPush('css'); ?>
    <style>
        .warperContext {
            border: 1px solid rgb(235, 230, 230);
            border-radius: 5px;
            /* overflow-y: scroll; */
            padding: 4px;
            box-shadow: 2px 3px 4px #b7b3b3c3;
        }
        
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row justify-content-center">
       
       <div class="col-md-8">
           <!-- general form elements -->
           <div class="card">
               
               <div class="card-header">
                   <div class="row justify-content-between">
                           <div class="col-md-8">
                               <h3 class="card-title">Condition & praivcy</h3>

                           </div>
                   </div>
               </div>
               <!-- /.card-header -->
               <!-- form start -->
               <form method="post" action="<?php echo e(route('conditions.update')); ?>" id="setting-form"  enctype="multipart/form-data">
                   <?php echo csrf_field(); ?>
                       <div class="catainer-fluid">
                           <div class="row  p-4">
                               <div class="from-group">
                                   
                                       
                                   
                                   <div class="col-md-11">
                                     <label for="">Condition & praivcy</label>
                                     <textarea name="content" id="" rows="11" cols="100"  class="form-control" placeholder="Condition & praivcy"><?php echo e($condition->content); ?></textarea>
                                      
                                   </div>

                               </div>

                              

                               </div>
                           </div>

                       </div>
                   <div class="card-footer">
                       <button type="submit" class="btn btn-sm btn-primary">Save</button>
                   </div>
                </form>
            </div>
        </div>
    

   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/setting/condition.blade.php ENDPATH**/ ?>