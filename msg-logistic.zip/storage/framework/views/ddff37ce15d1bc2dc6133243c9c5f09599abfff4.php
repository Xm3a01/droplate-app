<div>
    <div class="card-body">
        <div class="row my-4 justify-content-between">
            
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-8">
                        <form id="filter-form">
                            <label for="">Name</label>
                            <input type="text" name="" placeholder="Name" id="name" class="form-control form-control-sm">
                    </div>
                    
                    <div class="col-md-12 mt-4">
                        <button type="submit" class="btn btn-info btn-xs"> <i class="fa fa-filter"></i>
                            Filter</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <table id="region-table" class="table table-bordered table-striped">
            <thead class="bg-dark">
                <tr>
                    <th>Region Ar Name</th>
                    <th>Region  Name</th>
                    <th>Queck delivery  price</th>
                    <th>Normal delivery  price</th>
                    <th>Date</th>
                    
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
            </tfoot>
        </table>
    </div>

</div>
<?php /**PATH D:\Projects\msg-logistic\resources\views\components\region\region-html.blade.php ENDPATH**/ ?>