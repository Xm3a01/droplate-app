

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <!-- general form elements -->
        <div class="card ">
            <div class="card-header">
                <h3 class="card-title">Order Products </h3>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e($order->product->images[0]->getUrl()); ?>" alt="Card image cap">
                        <div class="card-body">
                          
                              <div class="row justify-content-between text-lg">
                                  <div class="col-md-4">
                                    <?php echo e($order->product->name); ?>

                                  </div>
                                  <div class="col-md-4">
                                    <?php echo e($order->product->selling_price); ?>

                                </div>
                              </div>
                          
                          <hr>
                            <p class="card-text">
                              <?php echo e($order->product->descripton); ?>

                            .</p>
                         
                        </div>
                      </div>
                </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views\app\order\show.blade.php ENDPATH**/ ?>