<html>

<head>
    <link rel="shortcut icon" href="<?php echo e(asset('images/ms.png')); ?>" style="width: 100%; " type="image/png">
    <title>Droplate</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login-style.css')); ?>">

<body class="layer2">
    <div class="body-cover"></div>
    <div class="loginbox  layer1">
        <div>
            <img src="<?php echo e(asset('images/ms.png')); ?>" class="avatar">
        </div>

        <form role="form" method="POST" action="<?php echo e(route('admin.login')); ?>">
            <?php echo csrf_field(); ?>
            <p class="head-title">E-mail</p>
            <input type="text" name="email" placeholder="Enter E-mail" value="<?php echo e(old('email')); ?>"
                class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" style="display: block; background:#fff; border-radius:2px; padding:4px; margin-bottom:4px" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password"
                class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('password')): ?>
            <span class="invalid-feedback" style="display: block; background:#fff; border-radius:2px; padding:4px; margin-bottom:4px" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
            <input type="submit" name="submit" value="LOGIN">
        </form>

    </div>

</body>
</head>

</html>
<?php /**PATH D:\Projects\msg-logistic\resources\views\auth\login.blade.php ENDPATH**/ ?>