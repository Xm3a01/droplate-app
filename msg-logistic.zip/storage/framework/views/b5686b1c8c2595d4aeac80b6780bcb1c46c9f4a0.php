<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('images/ms.png')); ?>" style="width: 100%; " type="image/png">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome-free/css/all.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/js/chart/Chart.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    
    
    <?php echo $__env->yieldPushContent('css'); ?>

    <!-- Styles -->
    
</head>

<body class="sidebar-mini layout-fixed">
    <div class="wrapper">

        
        <?php echo $__env->make('app._include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Main Sidebar Container -->
        <?php echo $__env->make('app._include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

            
            <?php echo $__env->make('app._include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            

        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/boostrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/admin/adminlte.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/pages/dashboard3.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
    
    
    
    
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    
    <?php echo $__env->make('app._include.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(function() {
            //Initialize Select2 Elements
            // $('.select2').select2();

            // //Initialize Select2 Elements
            // $('.select2bs4').select2({
            //     theme: 'bootstrap4'
            // })

            // bsCustomFileInput.init();
            // bsCustomFileInput.init();
        })
    </script>
</body>

</html>
<?php /**PATH D:\Projects\msg-logistic\resources\views/layouts/app.blade.php ENDPATH**/ ?>