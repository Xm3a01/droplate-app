


<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-11">
            <!-- general form elements -->
            <div class="card card-dark">
                <div class="card-header">
                    <h3 class="card-title">Update Category</h3>
                </div>
                <div class="card-body conatiner-fluid">

                    <form method="post" action="<?php echo e(route('categories.update' , $category->id)); ?>" id="app" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-body container">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="">Arabic name</label>
                                    <input type="text" name="ar_name" id=""  value="<?php echo e($category->ar); ?>"
                                      class="form-control form-control-sm" placeholder="Arabic name">
                                </div>
                                <div class="col-md-6">
                                    <label for="">English name</label>
                                    <input type="text" name="name" id="" value="<?php echo e($category->en); ?>"
                                      class="form-control form-control-sm" placeholder="English name">
    
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/category/edit.blade.php ENDPATH**/ ?>