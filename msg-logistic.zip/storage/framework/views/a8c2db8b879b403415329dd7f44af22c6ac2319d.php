


<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-dark">
                <div class="card-header">
                    <h3 class="card-title">Reciving Form</h3>
                </div>

                <form method="post" action="<?php echo e(route('products.update' , $product->id)); ?>" id="app" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <product-form 
                        categories = "<?php echo e($categories); ?>" 
                        sub_categories = "<?php echo e($sub_categories); ?>" 
                        product = <?php echo e($product); ?>

                        errors = "<?php echo e(count($errors->all()) > 0 ? json_encode($errors->all()) : null); ?>"
                      ></product-form>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-sm btn-primary">Save Change</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/product/edit.blade.php ENDPATH**/ ?>