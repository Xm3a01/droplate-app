


<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-dark">
                <div class="card-header">
                    <h3 class="card-title">Reciving Form</h3>
                </div>

                <form method="post" action="<?php echo e(route('products.update' , $product->id)); ?>" id="app" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-body p-4" id="app">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                                <select name="" id="" class="form-control form-control-sm">
                                    <option value="">Categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="$category->id"><?php echo e($category->name); ?></option>                                       
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <select name="" id="" class="form-control form-control-sm">
                                    <option value="">Sub Categories</option>
                                    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="$subCategory->id"> <?php echo e($subCategory->name); ?></option>                                       
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                  
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-6">
                            <label>Product AR name</label>
                            <input
                              name="ar_name"
                              class="form-control form-control-sm thingSelect"
                              style="width: 100%"
                              placeholder="Arabic name"
                              required
                              value="<?php echo e($product->getTranslation('name' , 'ar')); ?>"
                            />
                          </div>
                          <div class="col-md-6">
                            <label>Product EN name</label>
                            <input
                              name="en_name"
                              class="form-control form-control-sm"
                              style="width: 100%"
                              placeholder="English name"
                              required
                              value="<?php echo e($product->getTranslation('name' , 'en')); ?>"
                            />
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-6">
                            <label for="exampleInputEmail1">Quantity</label>
                            <input
                              type="text"
                              name="quantity"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                              placeholder="Enter Quantity"
                              required
                              value="<?php echo e($product->quantity); ?>"
                            />
                          </div>
                          <div class="col-md-6">
                            <label for="exampleInputEmail1">Discount</label>
                            <input
                              type="text"
                              name="discount"
                              class="form-control form-control-sm"
                              id=""
                              placeholder="Enter Discount"
                              value="<?php echo e($product->discount); ?>"
                            />
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-4">
                            <label for="exampleInputEmail1">Selling price</label>
                            <input
                              type="text"
                              name="selling_price"
                              class="form-control form-control-sm"
                              id=""
                              placeholder="Enter Selling price"
                              required
                              value="<?php echo e($product->selling_price); ?>"
                            />
                          </div>
                          <!-- purchasing_price -->
                          <div class="col-md-4">
                            <label for="exampleInputEmail1">Wholesale price</label>
                            <input
                              type="text"
                              name="wholesale_price"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                              placeholder="Enter Wholesale price"
                              required
                              value="<?php echo e($product->wholesale_price); ?>"
                            />
                          </div>
                          <div class="col-md-4">
                            <label for="exampleInputEmail1">Purchasing price</label>
                            <input
                              type="text"
                              name="purchasing_price"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                              placeholder="Enter Purchasing price"
                              required
                              value="<?php echo e($product->purchasing_price); ?>"
                            />
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12">
                            <label for="exampleInputEmail1">English Description</label>
                            <textarea
                              type="text"
                              name="en_description"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                              placeholder="Enter Description"
                              required
                            >
                            <?php echo e($product->getTranslation('descripton' , 'en')); ?>

                            </textarea>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12">
                            <label for="exampleInputEmail1">Arabic Description </label>
                            <textarea
                              type="text"
                              name="ar_description"
                              class="form-control form-control-sm"
                              id="exampleInputEmail1"
                              placeholder="Enter Description"
                              required
                            >
                            <?php echo e($product->getTranslation('descripton' , 'ar')); ?>

                            </textarea>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12">
                            <input-image />
                          </div>    
  
                        </div>
                      </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-sm btn-primary">Save Change</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/app/product/edit.blade.php ENDPATH**/ ?>