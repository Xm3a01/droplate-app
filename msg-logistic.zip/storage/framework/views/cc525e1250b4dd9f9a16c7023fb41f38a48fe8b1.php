<div>
    <div class="card-body">
        <div class="row my-4 justify-content-between">
            
            <div class="col-md-6">
                <div class="row">
                    
                    
                    
                    </form>
                </div>
            </div>
        </div>
        <table id="promo-table" class="table table-bordered table-striped">
            <thead class="bg-dark">
                <tr>
                    <th>Code</th>
                    <th>Price</th>
                    <th>Start Date</th>
                    <th>Expir Date</th>
                    
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
            </tfoot>
        </table>
    </div>

</div>
<?php /**PATH D:\Projects\msg-logistic\resources\views/components/promo/promo-html.blade.php ENDPATH**/ ?>