

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row justify-content-between">
                                <div class="col-md-11 " id="buttonData">
                                    <h3 class="card-title d-sm-none d-lg-block">
                                        PromoCode
                                    </h3>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                        data-target="#modal-lg">
                                        <i class="fa fa-plus"></i> New
                                    </button>
                                </div>
                            </div>
                        </div>

                        <?php if (isset($component)) { $__componentOriginal9c066ed35fd76ceafdd493835ae5d714dacb44ad = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Promo\PromoHtml::class, []); ?>
<?php $component->withName('promo.promo-html'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c066ed35fd76ceafdd493835ae5d714dacb44ad)): ?>
<?php $component = $__componentOriginal9c066ed35fd76ceafdd493835ae5d714dacb44ad; ?>
<?php unset($__componentOriginal9c066ed35fd76ceafdd493835ae5d714dacb44ad); ?>
<?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">New Promo Code</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('promoes.store')); ?>" id="create-form" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="">Price</label>
                                    <input type="text" placeholder="Price" name="price" id=""
                                        class="form-control form-control-sm" autocomplete="" required>
                                </div>

                                <div class="col-md-6 mt-2">
                                    <label for="">Start date</label>
                                    <input type="date" name="start_date" id="" placeholder="Start date"
                                        class="form-control from-control" required>
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label for="">Expir Date</label>
                                    <input type="date" placeholder="Start date" name="end_date" id=""
                                        class="form-control form-control" required>
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>

            </div>

        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('js'); ?>
        <?php if (isset($component)) { $__componentOriginal467e853e84c24eb311a7cc7173bc9451f82facce = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Promo\PromoJs::class, []); ?>
<?php $component->withName('promo.promo-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal467e853e84c24eb311a7cc7173bc9451f82facce)): ?>
<?php $component = $__componentOriginal467e853e84c24eb311a7cc7173bc9451f82facce; ?>
<?php unset($__componentOriginal467e853e84c24eb311a7cc7173bc9451f82facce); ?>
<?php endif; ?>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views\app\promocode\index.blade.php ENDPATH**/ ?>