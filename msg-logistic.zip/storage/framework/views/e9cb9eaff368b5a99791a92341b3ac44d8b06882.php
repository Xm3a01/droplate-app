

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box bg-info">
                    <span class="info-box-icon"><i class="fas fa-th"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Products</span>
                        <span class="info-box-number"><?php echo e($products); ?></span>
                        <div class="progress">
                            <div class="progress-bar" style="width: <?php echo e(($products/60000) *100); ?>"></div>
                        </div>
                        <span class="progress-description">
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box bg-success">
                    <span class="info-box-icon"><i class="fas fa-columns"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Brands</span>
                        <span class="info-box-number"><?php echo e($brands); ?></span>
                        <div class="progress">
                            <div class="progress-bar" style="width: <?php echo e(($brands/60000) *100); ?>"></div>
                        </div>
                        <span class="progress-description">
                        </span>
                    </div>

                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box bg-danger">
                    <span class="info-box-icon"><i class="fa fa-copy"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Orders</span>
                        <span class="info-box-number"><?php echo e($orders); ?></span>
                        <div class="progress">
                            <div class="progress-bar" style="width: <?php echo e(($orders/60000) *100); ?>"></div>
                        </div>
                        <span class="progress-description">
                        </span>
                    </div>

                </div>
            </div>
        </div>

        
        
      </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('js'); ?>
        
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\msg-logistic\resources\views/dashboard.blade.php ENDPATH**/ ?>