@extends('layouts.app')



@section('content')
    <x-data-table></x-data-table>
@endsection
@push('js')
    <x-js></x-js>
@endpush